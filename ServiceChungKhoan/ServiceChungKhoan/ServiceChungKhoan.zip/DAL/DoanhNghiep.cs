﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiceChungKhoan.DAL
{
    public class DoanhNghiep
    {
    public string MaCK { get; set; }
	public string SanGD { get; set; }
	public string TenDoanhNghiep { get; set; }
	public string Nganh { get; set; }
	public string DiaChi { get; set; }
	public string DienThoai { get; set; }
	public string fax { get; set; }
	public string website { get; set; }
    }
}